const express = require("express")
const server = express();

server.get("/",(req,res)=>
{
   return res.json ({mensagem:("servidor funcionado ok")})
}
)
server.get("/ping",(req,res)=>
{
    return res.json ("pong")
}
)
server.get("/pong",(req,res)=>
{
    return res.json ("ping")
}
)
server.listen(3000,()=>
{
    console.log("servidor funcionando")
}
);